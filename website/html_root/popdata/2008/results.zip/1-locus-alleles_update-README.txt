On August 16, 2010, we updated the 1-locus-alleles.dat file included in the results.zip file available
from www.pypop.org/popdata/ as Supporting online material for Solberg et al., Balancing selection and 
heterogeneity across the classical human leukocyte antigen loci: a meta-analytic review of 497 population 
studies. Hum Immunol. 2008 Jul;69(7):443-64. 

The following changes were made to the file in order to make this file consistent with the 
1-locus-summary.dat file and the results presented in the paper:
1. Data for the Gidra_1995 population were deleted from the 1-locus-alleles.dat file.
2. The region of the Colombian(Af) population was changed from SSA to OTH.
3. The region of the North_America(Af) population was changed from SSA to OTH.

On December 29, 2010, we updated the 1-locus-alleles.dat file included in the results.zip file
(described above).

The following changes were made to the file:
1. All instances of the DPB1*0902 allele were changed to DPB1*1301. 
2. All instances of the DPB1*0802 allele were changed to DPB1*1901. 
3. The name of the "allele" column was changed to "allele_v2".
4. A column named "allele_v3" was added. This column contains the IMGT/HLA database version 3.2.0
allele names corresponding to the allele names in the "allele_v2" column, as defined in: 
Marsh et al. Nomenclature for Factors of the HLA System, 2010. Tissue Antigens 2010 75:291-455, and
Marsh et al. Nomenclature for Factors of the HLA System, update September 2010. Hum Immunol. 2011 72:103-5.

Changes 1. and 2. were made because DPB1*0902 and DPB1*0802 were not reported in any of the 
population datasets included in the analysis. Instead, DPB1*1301 and DPB1*1901 alleles were
binned into these allele categories because each shares an identical exon2 sequences with
the respective aforementioned allele. The identifier of the binned category was chosen based on 
the lower numbered allele. Under the 2010 version of the HLA allele name nomenclature, DPB1*0802 
and DPB1*0902 correspond to DPB1*106:01 and DPB1*107:01 respectively, which are higher numbered
than the DPB1*19:01 and DPB1*13:01 alleles. 

The DPB1 filter section of the config-allelecount.ini file was modified to reflect these changes as well.  

If you have questions about these changes, contact Steven J. Mack, at sjmack@chori.org
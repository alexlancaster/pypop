@echo off
set PYTHONHOME="."
bin\popmeta.exe -i
pause
@echo off
set PYTHONHOME="."
bin\popmeta.exe %*
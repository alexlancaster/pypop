@echo off
set PYTHONHOME="."
bin\pypop.exe -i
pause